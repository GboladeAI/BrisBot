package com.bean;

public class SocietiesDetails {
	 private	String	vSOCIETIES ;
	 private	String	vSOCIETIES_NAME;
	 private	String	vSOCIETIESDETAILSID ;
	 private	String	vSOCIETIESDETAILSNAME;
	 
	 public void setSOCIETIES(String temp){
		 vSOCIETIES = temp;
	    }
	    public void setSOCIETIES_NAME(String temp){
	    	vSOCIETIES_NAME = temp;
	    }
	    
	    public void setSOCIETIESDETAILSID(String temp){
	    	vSOCIETIESDETAILSID = temp;
		    }
		    public void setSOCIETIESDETAILSNAME(String temp){
		    	vSOCIETIESDETAILSNAME = temp;
		    }
	    
	    
	    public String getSOCIETIES(){
	    	return vSOCIETIES ;
	    }
	    public String getSOCIETIES_NAME(){
	    	return vSOCIETIES_NAME ;
	    }
	    
	    public String getSOCIETIESDETAILSID(){
	    	return vSOCIETIESDETAILSID ;
	    }
	    public String getSOCIETIESDETAILSNAME(){
	    	return vSOCIETIESDETAILSNAME ;
	    }
	    
	    
	    public SocietiesDetails(){}

	    public SocietiesDetails(	 	String	vSOCIETIES ,
		 	String	vSOCIETIES_NAME,
		 	 	String	vSOCIETIESDETAILSID,
		 	String	vSOCIETIESDETAILSNAME
		 
	    		) {
	    	this.vSOCIETIES  	=	vSOCIETIES  	;
	    	this.vSOCIETIES_NAME 	=	vSOCIETIES_NAME 	;
	    	this.vSOCIETIESDETAILSID 	=	vSOCIETIESDETAILSID 	;
	    	this.vSOCIETIESDETAILSNAME 	=	vSOCIETIESDETAILSNAME 	;
	    		    }


}
