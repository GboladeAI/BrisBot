package com.bean;

public class Societies {

	 private	String	vSOCIETIES ;
	 private	String	vSOCIETIES_NAME;
	 
	 public void setSOCIETIES(String temp){
		 vSOCIETIES = temp;
	    }
	    public void setSOCIETIES_NAME(String temp){
	    	vSOCIETIES_NAME = temp;
	    }
	    
	    public String getSOCIETIES(){
	    	return vSOCIETIES ;
	    }
	    public String getSOCIETIES_NAME(){
	    	return vSOCIETIES_NAME ;
	    }
	    
	    
	    public Societies() {
	    }

	   

	    public Societies(	 	String	vSOCIETIES ,
		 	String	vSOCIETIES_NAME
	    		) {
	    	this.vSOCIETIES  	=	vSOCIETIES  	;
	    	this.vSOCIETIES_NAME 	=	vSOCIETIES_NAME 	;
	    	
	    		    }

	    
	    
	    
	    
	    

}
