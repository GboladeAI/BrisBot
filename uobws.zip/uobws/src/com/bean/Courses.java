
package com.bean;

//a.COURSESID, a.COURSENAME

public class Courses {
	//a.DEGREEID, a.DEGREENAME
	 private	String	vCOURSESID ;
	 private	String	vCOURSENAME;
	 
	 public void setCOURSESID(String temp){
		 vCOURSESID = temp;
	    }
	    public void setCOURSENAME(String temp){
	    	vCOURSENAME = temp;
	    }
	    
	    public String getCOURSESID(){
	    	return vCOURSESID ;
	    }
	    public String getCOURSENAME(){
	    	return vCOURSENAME ;
	    }
	    
	    
	    public Courses() {
	    }

	   

	    public Courses(	 	String	vCOURSESID ,
		 	String	vCOURSENAME
	    		) {
	    	this.vCOURSESID  	=	vCOURSESID  	;
	    	this.vCOURSENAME 	=	vCOURSENAME 	;
	    	
	    		    }

	
	

}
