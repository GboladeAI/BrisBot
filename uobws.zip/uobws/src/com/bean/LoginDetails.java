package com.bean;


import java.io.Serializable;
import java.util.Date;
import java.util.Date;
	public class LoginDetails implements Serializable {
	    private static final long serialVersionUID = 1L;
	    private	String	vSURNAME ;
	    private	String	vFIRSTNAME;
	    private	String	vFACULTYID ;
	    private	String	vFACULTYNAME;
	    private	String	vCOURSEID;
	    private	String	vCOURSENAME;
	    private	String	vADMISSIONYEAR;
	    private	String	vDEGREEID;
	    private	String	vDEGREENAME;
	    private	String	vPASSWORD;
	    private	String	vLOGINATTEMPTS;
	    private	String	vLASTLOGINDATE;
	    private	String	vSTATUS;
	    private	String	vRESPONSECODE;
	    
	    public void setSURNAME(String temp){
	    	vSURNAME = temp;
	    }
	    public void setFIRSTNAME(String temp){
	    	vFIRSTNAME = temp;
	    }
	    public void setFACULTYID(String temp){
	    	vFACULTYID = temp;
	    }
	    public void setFACULTYNAME(String temp){
	    	vFACULTYNAME = temp;
	    }
	    public void setCOURSEID(String temp){
	    	vCOURSEID = temp;
	    }
	    
	    public void setCOURSENAME(String temp){
	    	vCOURSENAME = temp;
	    }
	    public void setADMISSIONYEAR(String temp){
	    	vADMISSIONYEAR = temp;
	    }
	    public void setDEGREEID(String temp){
	    	vDEGREEID = temp;
	    }
	    public void setDEGREENAME(String temp){
	    	vDEGREENAME = temp;
	    }
	    public void setPASSWORD(String temp){
		    vPASSWORD = temp;
	    }
	    public	void setLOGINATTEMPTS(String temp){
		    vLOGINATTEMPTS = temp;
	    }
	    public	void setLASTLOGINDATE(String temp){
		    vLASTLOGINDATE = temp;
	    }
	    public	void setSTATUS(String temp){
		    vSTATUS = temp;
	    }
	    public	void setRESPONSECODE(String temp){
	    	vRESPONSECODE = temp;
	    }
	    
	    
	    public String getSURNAME(){
	    	return vSURNAME ;
	    }
	    public String getFIRSTNAME(){
	    	return vFIRSTNAME ;
	    }
	    public String getFACULTYID(){
	    	return vFACULTYID ;
	    }
	    public String getFACULTYNAME(){
	    	return vFACULTYNAME ;
	    }
	    public String getCOURSEID(){
	    	return vCOURSEID ;
	    }
	    
	    public String getCOURSENAME(){
	    	return vCOURSENAME ;
	    }
	    public String getADMISSIONYEAR(){
	    	return vADMISSIONYEAR ;
	    }
	    public String getDEGREEID(){
	    	return vDEGREEID ;
	    }
	    public String getDEGREENAME(){
	    	return vDEGREENAME ;
	    }
	    public String getPASSWORD(){
		    return vPASSWORD ;
	    }
	    public String getLOGINATTEMPTS(){
		    return vLOGINATTEMPTS ;
	    }
	    public String getLASTLOGINDATE(){
		    return vLASTLOGINDATE ;
	    }
	    public String getSTATUS(){
		    return vSTATUS ;
	    }
	    public String getRESPONSECODE(){
	    	return vRESPONSECODE ;
	    }
	    
	    
	    
	    public LoginDetails() {
	    }

	   

	    public LoginDetails(	String	vSURNAME  
	    		,	String	vFIRSTNAME 
	    		,	String	vFACULTYID 
	    		,	String	vFACULTYNAME 
	    		,	String	vCOURSEID 
	    		,	String	vCOURSENAME 
	    		,	String	vADMISSIONYEAR 
	    		,	String	vDEGREEID 
	    		,	String	vDEGREENAME 
	    		,	String	vPASSWORD 
	    		,	String	vLOGINATTEMPTS
	    		,	String	vLASTLOGINDATE 
	    		,	String	VSTATUS  
	    		,	String	vRESPONSECODE
	    		
	    		) {
	    	this.vSURNAME  	=	vSURNAME  	;
	    	this.vFIRSTNAME 	=	vFIRSTNAME 	;
	    	this.vFACULTYID 	=	vFACULTYID 	;
	    	this.vFACULTYNAME 	=	vFACULTYNAME 	;
	    	this.vCOURSEID 	=	vCOURSEID 	;
	    	this.vCOURSENAME 	=	vCOURSENAME 	;
	    	this.vADMISSIONYEAR 	=	vADMISSIONYEAR 	;
	    	this.vDEGREEID 	=	vDEGREEID 	;
	    	this.vDEGREENAME 	=	vDEGREENAME 	;
	    	this.vPASSWORD 	=	vPASSWORD 	;
	    	this.vLOGINATTEMPTS	=	vLOGINATTEMPTS	;
	    	this.vLASTLOGINDATE 	=	vLASTLOGINDATE 	;
	    	this.vSTATUS 	=	vSTATUS 	;
	    	this.vRESPONSECODE	=	vRESPONSECODE	;
	    		    }

	    
	    
	    
	    
}
