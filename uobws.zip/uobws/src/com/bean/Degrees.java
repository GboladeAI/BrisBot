package com.bean;

public class Degrees {
	//a.DEGREEID, a.DEGREENAME
	 private	String	vDEGREEID ;
	 private	String	vDEGREENAME;
	 
	 public void setDEGREEID(String temp){
		 vDEGREEID = temp;
	    }
	    public void setDEGREENAME(String temp){
	    	vDEGREENAME = temp;
	    }
	    
	    public String getDEGREEID(){
	    	return vDEGREEID ;
	    }
	    public String getDEGREENAME(){
	    	return vDEGREENAME ;
	    }
	    
	    
	    public Degrees() {
	    }

	   

	    public Degrees(	 	String	vDEGREEID ,
		 	String	vDEGREENAME
	    		) {
	    	this.vDEGREEID  	=	vDEGREEID  	;
	    	this.vDEGREENAME 	=	vDEGREENAME 	;
	    	
	    		    }

	
	

}
