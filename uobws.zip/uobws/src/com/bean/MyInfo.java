package com.bean;

public class MyInfo {

	private Societies[] societies;
	private Courses[] courses;
	private Degrees[] degrees;
	private SocietiesDetails[] societiesDetails;
    
    public MyInfo() {
    }

    public MyInfo(
    		Societies[] societies,
    		Courses[] courses,
    		 Degrees[] degrees,
    		 SocietiesDetails[] societiesDetails
    		) {
           this.societies = societies;
           this.courses = courses;
           this.degrees = degrees;
           this.societiesDetails = societiesDetails;
           
       
    }


    public Societies[] getSocieties() {
        return societies;
    }
    public Courses[] getCourses() {
        return courses;
    }
   
    public Degrees[] getDegrees() {
        return degrees;
    }
   
    public SocietiesDetails[] getSocietiesDetails() {
        return societiesDetails;
    }
   
   
    public void setSocieties(Societies[] societies) {
        this.societies = societies;
    }
    public void setCourses(Courses[] courses) {
        this.courses = courses;
    }
    
    public void setDegrees(Degrees[] degrees) {
        this.degrees = degrees;
    }
    public void setSocietiesDetails(SocietiesDetails[] societiesDetails) {
        this.societiesDetails = societiesDetails;
    }
   
    
    
    
}
