
package com.robot;
//---alter table DASH019199.TBL_PEOPLESOCIETITES add constraint PK_SOCIETIES primary key (UNIVERSITYEMAILADDRESS, SOCIETIESDETAILSID)


import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Courses;
import com.bean.Degrees;
import com.bean.LoginDetails;
import com.bean.MyInfo;
import com.bean.Societies;
import com.bean.SocietiesDetails;
import com.robot.DatabaseProcess;
import com.robot.ScriptGenerator;
import com.robot.pwdcreation;

public class UoBRobotservices1 {
	
	
	public LoginDetails getAuthentication( String universityemailaddress, String password )
	{
		 
		 String ret="";
		 LoginDetails vLoginDetails = new LoginDetails()		 ;
		 ArrayList vArrList=null;
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		
		pwdcreation pwdgen = new pwdcreation();
		ScriptGenerator ss =new ScriptGenerator();
		ArrayList arrval = new ArrayList();
		
		//String mypass = pwdgen.pwdcreationgen(password);
		
			vArrList = ss.Authentication_Email(conn, universityemailaddress);
          ArrayList RowAl = new ArrayList();
			if (vArrList.size()>=1)
			{
				
				RowAl= (ArrayList)vArrList.get(0);
				vLoginDetails.setSURNAME(RowAl.get(0).toString()) ;
			    vLoginDetails.setFIRSTNAME(RowAl.get(1).toString()) ;
			    vLoginDetails.setFACULTYID(RowAl.get(2).toString()) ;
			    vLoginDetails.setFACULTYNAME(RowAl.get(3).toString()) ;
			    vLoginDetails.setCOURSEID(RowAl.get(4).toString()) ;
			    vLoginDetails.setCOURSENAME(RowAl.get(5).toString()) ;
			    vLoginDetails.setADMISSIONYEAR(RowAl.get(6).toString()) ;
			    vLoginDetails.setDEGREEID(RowAl.get(7).toString()) ;
			    vLoginDetails.setDEGREENAME(RowAl.get(8).toString()) ;
			    vLoginDetails.setPASSWORD(RowAl.get(9).toString()) ;
			    vLoginDetails.setLOGINATTEMPTS(RowAl.get(10).toString()) ;
			    vLoginDetails.setLASTLOGINDATE(RowAl.get(11).toString()) ;
			    vLoginDetails.setSTATUS(RowAl.get(12).toString()) ;
			    vLoginDetails.setRESPONSECODE("00") ;

				RowAl=null;
					
		}else
		{
			
			vLoginDetails.setSURNAME("") ;
		    vLoginDetails.setFIRSTNAME("") ;
		    vLoginDetails.setFACULTYID("") ;
		    vLoginDetails.setFACULTYNAME("") ;
		    vLoginDetails.setCOURSEID("") ;
		    vLoginDetails.setCOURSENAME("") ;
		    vLoginDetails.setADMISSIONYEAR("") ;
		    vLoginDetails.setDEGREEID("") ;
		    vLoginDetails.setDEGREENAME("") ;
		    vLoginDetails.setPASSWORD("") ;
		    vLoginDetails.setLOGINATTEMPTS("") ;
		    vLoginDetails.setLASTLOGINDATE("") ;
		    vLoginDetails.setSTATUS("") ;
		    vLoginDetails.setRESPONSECODE("01") ;

			RowAl=null;
		}
			arrval=null;
		
			
		
		
		
		return vLoginDetails;

	}
	public MyInfo getSocieties( String paramStatus )
	{
		 
		 String ret="";
		
		 MyInfo vMyInfo = new MyInfo();
		 ArrayList vArrList=null;
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		Societies var[] = null;
        
		ScriptGenerator ss =new ScriptGenerator();
		
		ArrayList arrval = new ArrayList();
		
		
			vArrList = ss.Societies(conn, paramStatus);
          ArrayList RowAl = new ArrayList();
          int arrsize=vArrList.size();
          var = new Societies[arrsize];
  		
			if (vArrList.size()>=1)
			{
				for (int i=0; i< arrsize; i++)
				{
				RowAl= (ArrayList)vArrList.get(i);
				 Societies vSocieties = new Societies()		 ;
				vSocieties.setSOCIETIES(RowAl.get(0).toString()) ;
				vSocieties.setSOCIETIES_NAME(RowAl.get(1).toString());
			    
				var[i]=vSocieties;
				
				RowAl=null;
				
				}
					
		}else
		{
			var = new Societies[1];
			 Societies vSocieties = new Societies()		 ;
			vSocieties.setSOCIETIES("") ;
			vSocieties.setSOCIETIES_NAME("");
		    var[0]=vSocieties;
			RowAl=null;
		}
			arrval=null;
			
			vMyInfo.setSocieties(var);
		
		return vMyInfo;

	}

	public MyInfo getSocietiesDetails( String paramStatus )
	{
		 
		 String ret="";
		
		 SocietiesDetails var[]=null; 
		 MyInfo vMyInfo = new MyInfo();
		 ArrayList vArrList=null;
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		
		
		ScriptGenerator ss =new ScriptGenerator();
		
		ArrayList arrval = new ArrayList();
		
		
			vArrList = ss.SocietiesDetails(conn, paramStatus);
			  var = new SocietiesDetails[vArrList.size()];
          ArrayList RowAl = new ArrayList();
			if (vArrList.size()>=1)
			{
				for(int i =0 ; i <vArrList.size(); i++)
				{
					 SocietiesDetails vSocietiesDetails = new SocietiesDetails()		 ;
				RowAl= (ArrayList)vArrList.get(i);
				vSocietiesDetails.setSOCIETIES(RowAl.get(0).toString()) ;
				vSocietiesDetails.setSOCIETIES_NAME(RowAl.get(1).toString());
				vSocietiesDetails.setSOCIETIESDETAILSID(RowAl.get(2).toString());
				vSocietiesDetails.setSOCIETIESDETAILSNAME(RowAl.get(3).toString());
			    
				var[i]=vSocietiesDetails;
				
				RowAl=null;
				}
					
		}else
		{
			var = new SocietiesDetails[1];
			 SocietiesDetails vSocietiesDetails = new SocietiesDetails()		 ;
			vSocietiesDetails.setSOCIETIES("");
			vSocietiesDetails.setSOCIETIES_NAME("");
			vSocietiesDetails.setSOCIETIESDETAILSID("");
			vSocietiesDetails.setSOCIETIESDETAILSNAME("");
			var[0]=vSocietiesDetails;
		
		    
			RowAl=null;
		}
			arrval=null;
		
			vMyInfo.setSocietiesDetails(var);
		
		
		
		return vMyInfo;

	}

	public MyInfo getDegrees( String param )
	{
		 
		 String ret="";
		 Degrees var[]=null; 
		 MyInfo vMyInfo = new MyInfo();
		 ArrayList vArrList=null;
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		
		
		ScriptGenerator ss =new ScriptGenerator();
		
		ArrayList arrval = new ArrayList();
		
		
			vArrList = ss.Degrees(conn, param);
			
			int arrsize=vArrList.size();
	       ArrayList RowAl = new ArrayList();
			if (vArrList.size()>=1)
			{
				  var = new Degrees[arrsize];
				  for(int i=0; i<arrsize; i++)
				  { 
					  Degrees vDegrees = new Degrees()		 ;
						
					  RowAl= (ArrayList)vArrList.get(i);
				vDegrees.setDEGREEID(RowAl.get(0).toString()) ;
				vDegrees.setDEGREENAME(RowAl.get(1).toString());
			    var[i]=vDegrees;
				RowAl=null;
				  }
		}else
		{
			 Degrees vDegrees = new Degrees()		 ;
				
			var = new Degrees[1];
			vDegrees.setDEGREEID("") ;
			vDegrees.setDEGREENAME("");
			var[0]=vDegrees;
			RowAl=null;
		}
			arrval=null;
		
			
		
		vMyInfo.setDegrees(var);
		
		return vMyInfo;

	}

	
	public MyInfo getCourses( String paramFACULTYID )
	{
		 
		 String ret="";
		 ArrayList vArrList=null;
		 
		 Courses var[]=null; 
		 MyInfo vMyInfo = new MyInfo();
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		
		
		ScriptGenerator ss =new ScriptGenerator();
	
		ArrayList arrval = new ArrayList();
		
		
			vArrList = ss.Courses(conn, paramFACULTYID);
          ArrayList RowAl = new ArrayList();
          int arrsize= vArrList.size();
          
          if (vArrList.size()>=1)
			{
                var = new Courses[arrsize]	 ; 
                for(int i=0; i<arrsize ; i++)
                {
           		 Courses vCourses = new Courses()		 ;

                	RowAl= (ArrayList)vArrList.get(i);
				vCourses.setCOURSESID(RowAl.get(0).toString());
				vCourses.setCOURSENAME(RowAl.get(1).toString());
				RowAl=null;
				var[i]=vCourses;
                }
					
		}else
		{

			var = new Courses[1]	 ; 
			 Courses vCourses = new Courses()		 ;

			vCourses.setCOURSESID("");
			vCourses.setCOURSENAME("");
			var[0]=vCourses;
			RowAl=null;
		}
			arrval=null;
		
			
		vMyInfo.setCourses(var);
		
		
		return vMyInfo;

	}

	
	public String CreateSocieties(String universityemailaddress,String societiesdetailsid,String status,
			String type)
	{
		String response="";
		String sql = "   ";
		
		if (type.equalsIgnoreCase("INSERT"))
		{
		 sql = " INSERT INTO DASH019199.TBL_PEOPLESOCIETITES ";
		sql=sql + " VALUES('"+universityemailaddress+"', "+societiesdetailsid+ ", '"+status+"' )";
		}
		if (type.equalsIgnoreCase("UPDATE"))
		{
		 sql = "UPDATE DASH019199.TBL_PEOPLESOCIETITES ";
		sql=sql + " SET STATUS = '"+status+"' ";
		sql=sql + " WHERE UNIVERSITYEMAILADDRESS = '"+universityemailaddress+"' ";
		}
		 System.out.println("sql :::"+sql);
		 DatabaseProcess dd =null;
		try {
			 dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			response = dd.executeInsertDB2(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			 System.out.println("Exceptio:::"+e.getMessage());
			 System.out.println("getLocalizedMessage:::"+e.getLocalizedMessage());
		}
	
		return "Y";
	}
}

