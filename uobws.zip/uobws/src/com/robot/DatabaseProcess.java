package com.robot;

/*
 *Author 		:Shada A Taiwo
 *
 *
 E:\ibank\jbossas\server\all\deploy\jboss-web.deployer
 
 
CREATE TABLE APARTMENT
 (HOMEOWNER_MOBILENUMBER1   VARCHAR(20) NOT NULL,
HOMEOWNER_ID   INTEGER NOT NULL,
  STREET  VARCHAR(60) NOT NULL,
  STREET1   VARCHAR(60) NULL,
  LGA VARCHAR(60) NOT NULL,        
STATE VARCHAR(60) NOT NULL,
COUNTRY VARCHAR(60) NOT NULL,
APARTNUMBER  VARCHAR(30) NOT NULL,
REGISTERDATE  DATE , 
APARTMENTTYPE  VARCHAR(60) NOT NULL,

APARTMENTDESCRIPTION VARCHAR(60) NOT NULL,
RENT      DECIMAL(16,2)  NOT NULL,

 CAUTIONFEE  DECIMAL(16,2)  NOT NULL,
apartmentcode  VARCHAR(60) ,
STATUS  CHAR(1)  NOT NULL,

 PRIMARY KEY(APARTNUMBER)          );

CREATE TABLE HOMEOWNER
 (HOMEOWNER_MOBILENUMBER1   VARCHAR(20) NOT NULL,
HOMEOWNER_MOBILENUMBER2   VARCHAR(20) NOT NULL,
HOMEOWNER_ID   INTEGER NOT NULL,
  STREET  VARCHAR(60) NOT NULL,
  STREET1   VARCHAR(60) NULL,
  LGA VARCHAR(60) NOT NULL,        
STATE VARCHAR(60) NOT NULL,
COUNTRY VARCHAR(60) NOT NULL,
EMAILADDRESS  VARCHAR(30) NOT NULL,
REGISTERDATE  DATE , 
FIRSTNAME  VARCHAR(30) NOT NULL,
MIDDLENAME  VARCHAR(30) ,
LASTNAME  VARCHAR(30) NOT NULL,

STATUS  CHAR(1)  NOT NULL,

 PRIMARY KEY(HOMEOWNER_ID)          );

TENANT_MOBILENUMBER, FIRSTNAME, LASTNAME  from  tenant
CREATE TABLE TENANT
 (APARTNUMBER  VARCHAR(30) NOT NULL,
TENANT_MOBILENUMBER   VARCHAR(20) NOT NULL,
TENANT_ID   INTEGER NOT NULL,
  STREET  VARCHAR(60) NOT NULL,
  STREET1   VARCHAR(60) NULL,
  LGA VARCHAR(60) NOT NULL,        
STATE VARCHAR(60) NOT NULL,
COUNTRY VARCHAR(60) NOT NULL,
EMAILADDRESS  VARCHAR(30) NOT NULL,
REGISTERDATE  DATE , 
FIRSTNAME  VARCHAR(30) NOT NULL,
MIDDLENAME  VARCHAR(30) ,
LASTNAME  VARCHAR(30) NOT NULL,

STATUS  CHAR(1)  NOT NULL,

 PRIMARY KEY(TENANT_ID)          );





CREATE TABLE ESTATECOY
 (HOMEOWNER_MOBILENUMBER1   VARCHAR(20) NOT NULL,
HOMEOWNER_MOBILENUMBER2   VARCHAR(20) NOT NULL,
COY_ID  INTEGER NOT NULL,
COY_NAME   VARCHAR(60) NOT NULL,
COY_REG_NO   VARCHAR(30) NOT NULL,
  STREET  VARCHAR(60) NOT NULL,
  STREET1   VARCHAR(60) NULL,
  LGA VARCHAR(60) NOT NULL,        
STATE VARCHAR(60) NOT NULL,
COUNTRY VARCHAR(60) NOT NULL,
EMAILADDRESS  VARCHAR(30) NOT NULL,
REGISTERDATE  DATE , 
FIRSTNAME  VARCHAR(30) NOT NULL,
MIDDLENAME  VARCHAR(30) ,
LASTNAME  VARCHAR(30) NOT NULL,

STATUS  CHAR(1)  NOT NULL,

 PRIMARY KEY(COY_ID)          );



CREATE TABLE ESTATEOFFICER
 (HOMEOWNER_MOBILENUMBER1   VARCHAR(20) NOT NULL,
HOMEOWNER_MOBILENUMBER2   VARCHAR(20) NOT NULL,
ESTATEOFFICER_ID   INTEGER NOT NULL,
  STREET  VARCHAR(60) NOT NULL,
  STREET1   VARCHAR(60) NULL,
  LGA VARCHAR(60) NOT NULL,        
STATE VARCHAR(60) NOT NULL,
COUNTRY VARCHAR(60) NOT NULL,
EMAILADDRESS  VARCHAR(30) NOT NULL,
REGISTERDATE  DATE , 
FIRSTNAME  VARCHAR(30) NOT NULL,
MIDDLENAME  VARCHAR(30) ,
LASTNAME  VARCHAR(30) NOT NULL,

STATUS  CHAR(1)  NOT NULL,

 PRIMARY KEY(ESTATEOFFICER_ID)          );


CREATE TABLE ESTATEOFFICER_APARTMENT
 (
ESTATEOFFICER_APARTMENT_ID  INTEGER NOT NULL,
ESTATEOFFICER_ID   INTEGER NOT NULL,
APARTNUMBER  INTEGER NOT NULL,

REGISTERDATE  DATE , 

STATUS  CHAR(1)  NOT NULL,

 PRIMARY KEY(ESTATEOFFICER_APARTMENT_ID)          );

——
CREATE TABLE RENT
 (
RENT_ID INTEGER NOT NULL,
TENANT_ID INTEGER NOT NULL,
APARTNUMBER  VARCHAR(60) NOT NULL,
BEGINDATE  DATE,
ENDDATE  DATE,
REGISTERDATE  DATE , 
DESCRIPTION  VARCHAR(60) NOT NULL,
RECEITPTNO  VARCHAR(120) ,
 CAUTIONFEE  DECIMAL(16,2)  ,
RENT      DECIMAL(16,2)  NOT NULL,
 PRIMARY KEY(RENT_ID)          );


 CREATE TABLE xusers
    (password                       VARCHAR(90 ),
    name                           VARCHAR(100 ),
    customerno                     VARCHAR(15 ),
    emailaddress                   VARCHAR(100 ),
    lastlogindate                  DATE,
    lastlogintime                  DATE,
    question                       VARCHAR(100 ),
    answer                         VARCHAR(100 ),
    block                          INTEGER,
    lastpwdchange                  DATE,
    datecreated                    DATE,
    createdby                      VARCHAR(100 ),
    username                       VARCHAR(40 ) NOT NULL,
    timecreated                    DATE,
    userprofile                    VARCHAR(1 ),
    trans_level                   INTEGER,

    auth_level                     INTEGER,

    trans_enabled                  VARCHAR(10 ),
    trans_post                     VARCHAR(10 ),
    cust_name                      VARCHAR(100 ),
    mobile                         VARCHAR(20 ),
    telephone                      VARCHAR(20 ),
    authby                         VARCHAR(100 ),
    dateauth                       DATE,
    flg_mnt_status                 CHAR(1 ),
    branch                         VARCHAR(100 ),
    mnt_by                         VARCHAR(100 ),
    mnt_date                       VARCHAR(20 ),
    tranpwd                        VARCHAR(90 ))
 
 
 
 *
 *
 */




import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.io.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.io.*;
import java.sql.DriverManager;
import java.util.Properties;

//import javax.naming.Context;
//import javax.naming.InitialContext;
//import javax.sql.DataSource;




import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.google.gson.JsonArray;

public class DatabaseProcess {

    

  
	public DatabaseProcess() throws FileNotFoundException {
	


    	
    }



    public Connection getInfoPoolConnection1() {

        Connection conn=null;
try{
        Context ctx = new InitialContext();
        	DataSource	myDataSource = (DataSource) ctx.lookup("jdbc/dashDB-mn");
		
			 conn = myDataSource.getConnection();
			 conn.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
        }catch(Exception ex){
        	ex.printStackTrace();
              System.out.println("ERROR in Driver:"+ ex.getMessage());
              conn=null;
        }




        return conn;
    }
    public Connection getInfoPoolConnection() {

        Connection conn=null;

        Properties props = new Properties();
 	   try{
 	        String strUrl = "jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB";
 	   props.put("user", "dash019199");
 	   props.put("password","lTR3LQiHdKl5");
 	       try{
 	    System.out.println("****ABOUT to make DB2 BLU CONNECTION SUCCESSFUL****");
 	    Class.forName("com.ibm.db2.jcc.DB2Driver");
 	conn = DriverManager.getConnection(strUrl, props); 
 	conn.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
 	System.out.println("****DB2 BLU CONNECTION SUCCESSFUL****");
 	       }catch(Exception ex){
 	           System.out.println("ERROR in Driver:"+ ex.getMessage());
 	           ex.printStackTrace();
 	       }

 	   }catch(Exception ex){System.out.println("ERROR in Driver:"+ ex.getMessage());
 	   }
 	   return conn;

    }
    
    public Connection getDBConnection() {

        Connection conn=null;

        Properties props = new Properties();
 	   try{
 	        String strUrl = "jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB";
 	   props.put("user", "dash019199");
 	   props.put("password","lTR3LQiHdKl5");
 	       try{
 	    System.out.println("****ABOUT to make DB2 BLU CONNECTION SUCCESSFUL****");
 	    Class.forName("com.ibm.db2.jcc.DB2Driver");
 	conn = DriverManager.getConnection(strUrl, props); 
 	conn.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
 	System.out.println("****DB2 BLU CONNECTION SUCCESSFUL****");
 	       }catch(Exception ex){
 	           System.out.println("ERROR in Driver:"+ ex.getMessage());
 	           ex.printStackTrace();
 	       }

 	   }catch(Exception ex){System.out.println("ERROR in Driver:"+ ex.getMessage());
 	   }
 	   return conn;

    }
    
    
    
    
    public Connection getConnectionDB2() {

        Connection conn=null;

        Properties props = new Properties();
 	   try{
 	        String strUrl = "jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB";
 	   props.put("user", "dash019199");
 	   props.put("password","lTR3LQiHdKl5");
 	       try{
 	    System.out.println("****ABOUT to make DB2 BLU CONNECTION SUCCESSFUL****");
 	    Class.forName("com.ibm.db2.jcc.DB2Driver");
 	conn = DriverManager.getConnection(strUrl, props); 
 	conn.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
 	System.out.println("****DB2 BLU CONNECTION SUCCESSFUL****");
 	       }catch(Exception ex){
 	           System.out.println("ERROR in Driver:"+ ex.getMessage());
 	           ex.printStackTrace();
 	       }

 	   }catch(Exception ex){System.out.println("ERROR in Driver:"+ ex.getMessage());
 	   }
 	   return conn;

    }
    
    
    
    public Connection getConnectionDB2old() {
    	 Connection conn=null;
	       Properties props = new Properties();
	   try{
	        String strUrl = "jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB";
	   props.put("user", "dash019199");
	   props.put("password","lTR3LQiHdKl5");
	       try{
	    System.out.println("****ABOUT to make DB2 BLU CONNECTION SUCCESSFUL****");
	    Class.forName("com.ibm.db2.jcc.DB2Driver");
	conn = DriverManager.getConnection(strUrl, props); 
	conn.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
	System.out.println("****DB2 BLU CONNECTION SUCCESSFUL****");
	       }catch(Exception ex){
	           System.out.println("ERROR in Driver:"+ ex.getMessage());
	           ex.printStackTrace();
	       }

	   }catch(Exception ex){System.out.println("ERROR in Driver:"+ ex.getMessage());
	   }
	   return conn;
	}

  
    
    public Connection getConnection() {

        Connection conn=null;

        Properties props = new Properties();
 	   try{
 	        String strUrl = "jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB";
 	   props.put("user", "dash019199");
 	   props.put("password","lTR3LQiHdKl5");
 	       try{
 	    System.out.println("****ABOUT to make DB2 BLU CONNECTION SUCCESSFUL****");
 	    Class.forName("com.ibm.db2.jcc.DB2Driver");
 	conn = DriverManager.getConnection(strUrl, props); 
 	conn.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
 	System.out.println("****DB2 BLU CONNECTION SUCCESSFUL****");
 	       }catch(Exception ex){
 	           System.out.println("ERROR in Driver:"+ ex.getMessage());
 	           ex.printStackTrace();
 	       }

 	   }catch(Exception ex){System.out.println("ERROR in Driver:"+ ex.getMessage());
 	   }
 	   return conn;

    }
    
    
    
    public Connection getDBConnection1() {
    	 Connection conn=null;

         try {
         	Context ctx = new InitialContext();
         	DataSource	myDataSource = (DataSource) ctx.lookup("jdbc/dashDB-mn");
 		
 			 conn = myDataSource.getConnection();
 			 conn.setTransactionIsolation( Connection.TRANSACTION_READ_UNCOMMITTED );
         }catch(Exception ex){
         	ex.printStackTrace();
               System.out.println("ERROR in Driver:"+ ex.getMessage());
               conn=null;
         }



         return conn;
	}
    public JsonArray getResultSetTOJsonfromSQLForDB2(String strSQL) throws SQLException{

        JsonArray myArrayList=null;
        Connection conn=null ;
        PreparedStatement pstmt1 =null;
        try{

        ResultSetToJson ResultSetToArrayListX = new ResultSetToJson();
        //conn = gettxnConnection();
       
    conn = this.getConnectionDB2();

    
         if (conn != null) {
    
         pstmt1 = conn.prepareStatement(strSQL);
       myArrayList= ResultSetToArrayListX.ResultSetToJson((ResultSet)pstmt1.executeQuery());
   
         }
         
         if (pstmt1 != null) {
   	      try { pstmt1.close(); } catch (SQLException e) { ; }
   	      pstmt1 = null;
   	    }
   	    if (conn != null) {
   	      try { conn.close(); } catch (SQLException e) { ; }
   	      conn = null;
   	    }
         
         
         
        }catch(SQLException e1){
       	e1.printStackTrace();
        System.out.println(e1.toString());
        }finally {
        	 if (pstmt1 != null) {
        	      try { pstmt1.close(); } catch (SQLException e) { ; }
        	      pstmt1 = null;
        	    }
        	    if (conn != null) {
        	      try { conn.close(); } catch (SQLException e) { ; }
        	      conn = null;
        	    }

        }

    System.out.println(myArrayList.toString());
        return myArrayList;
        }
    
  
    
        
    
    public Connection getBankingConnection() {

    	 Connection conn=null;
	       Properties props = new Properties();
	   try{
	        String strUrl = "jdbc:db2://bluemix05.bluforcloud.com:50000/BLUDB";
	   props.put("user", "dash019199");
	   props.put("password","lTR3LQiHdKl5");
	       try{
	    System.out.println("****ABOUT to make DB2 BLU CONNECTION SUCCESSFUL****");
	    Class.forName("com.ibm.db2.jcc.DB2Driver");
	conn = DriverManager.getConnection(strUrl, props); 
	System.out.println("****DB2 BLU CONNECTION SUCCESSFUL****");
	       }catch(Exception ex){
	           System.out.println("ERROR in Driver:"+ ex.getMessage());
	           ex.printStackTrace();
	       }

	   }catch(Exception ex){System.out.println("ERROR in Driver:"+ ex.getMessage());
	   }
	   return conn;
	}

    public ArrayList getResultSetTOArrayListfromSQLForDB2(String strSQL) throws SQLException{

        ArrayList myArrayList=null;
        Connection conn=null ;
        PreparedStatement pstmt1 =null;
        try{

        ResultSetToArrayList ResultSetToArrayListX = new ResultSetToArrayList();
        //conn = gettxnConnection();
        System.out.println("***strSQLstrSQL=="+strSQL);
    System.out.println("DatabaseProcess.getResultSetTOArrayListfromSQL() = 11111111111111111111111111111111111");
   
    conn = getInfoPoolConnection();

    System.out.println("DatabaseProcess.getResultSetTOArrayListfromSQL() = 222222222222222222222222222222222222");

         if (conn != null) {
    System.out.println("DatabaseProcess.getResultSetTOArrayListfromSQL() = 3333333333333333333333333333333333");

         pstmt1 = conn.prepareStatement(strSQL);
    System.out.println("DatabaseProcess.getResultSetTOArrayListfromSQL() = 444444444444444444444444444444444444");
        myArrayList= ResultSetToArrayListX.ResultSetToArrayList((ResultSet)pstmt1.executeQuery());
    System.out.println("DatabaseProcess.getResultSetTOArrayListfromSQL() = 55555555555555555555555555555555555");

         }
         
         
         if (pstmt1 != null) {
   	      try { pstmt1.close(); } catch (SQLException e) { ; }
   	      pstmt1 = null;
   	    }
   	    if (conn != null) {
   	      try { conn.close(); } catch (SQLException e) { ; }
   	      conn = null;
   	    }
         
         
        }catch(SQLException e1){
       // 	e1.printStackTrace();
        System.out.println(e1.toString());
        }finally {
        	 if (pstmt1 != null) {
        	      try { pstmt1.close(); } catch (SQLException e) { ; }
        	      pstmt1 = null;
        	    }
        	    if (conn != null) {
        	      try { conn.close(); } catch (SQLException e) { ; }
        	      conn = null;
        	    }

        }

    System.out.println("DatabaseProcess.getResultSetTOArrayListfromSQL() = 666666666666666666666666666666666666666");
    System.out.println(myArrayList.toString());
        return myArrayList;
        }
    public String executeInsertDB2(String strSQL) throws SQLException{


        Connection conn=null ;
        Statement stmt=null;
        String res="N";
        System.out.println("executeInsert="+strSQL);
        try{

     			conn= this.getConnectionDB2();
         if (conn != null)
            {
        	 stmt = conn.createStatement();
        	 stmt.executeUpdate(strSQL);
        	 stmt.executeUpdate("commit");
        
res="Y";        	 
if (stmt != null) {
	      try { stmt.close(); } catch (SQLException e) { ; }
	   stmt = null;
	    }
	    if (conn != null) {
	      try { conn.close(); } catch (SQLException e) { ; }
	      conn = null;
	    }

         }
        }catch(SQLException e1){
        System.out.println(e1.toString());
        res=e1.toString();
        }
        finally
        {

       	 if (stmt != null) {
       	      try { stmt.close(); } catch (SQLException e) { ; }
       	   stmt = null;
       	    }
       	    if (conn != null) {
       	      try { conn.close(); } catch (SQLException e) { ; }
       	      conn = null;
       	    }
        }
        
        return res;

    }

  
    public ArrayList getResultSetTOArrayListfromSQL(String strSQL) throws SQLException{

    ArrayList myArrayList=null;
    Connection conn=null ;
    PreparedStatement pstmt1 =null;
    try{

    ResultSetToArrayList ResultSetToArrayListX = new ResultSetToArrayList();
    //conn = gettxnConnection();
    System.out.println("***strSQLstrSQL=="+strSQL);
conn = getInfoPoolConnection();

     if (conn != null) {
     pstmt1 = conn.prepareStatement(strSQL);
    myArrayList= ResultSetToArrayListX.ResultSetToArrayList((ResultSet)pstmt1.executeQuery());

     }
    }catch(SQLException e1){
   // 	e1.printStackTrace();
    System.out.println(e1.toString());
    }finally {
    	 if (pstmt1 != null) {
    	      try { pstmt1.close(); } catch (SQLException e) { ; }
    	      pstmt1 = null;
    	    }
    	    if (conn != null) {
    	      try { conn.close(); } catch (SQLException e) { ; }
    	      conn = null;
    	    }

    }

System.out.println(myArrayList.toString());
    return myArrayList;
    }

    public HashMap getResultSetTOHashMapfromSQL(String strSQL) throws SQLException{

    HashMap myHashMap=null;
    Connection conn=null ;
    PreparedStatement pstmt1 =null;
    try{

    ResultSetToHashMap ResultSetToHashMapX = new ResultSetToHashMap();
    //conn = gettxnConnection();
    conn = getInfoPoolConnection();
     if (conn != null)
        {
     pstmt1 = (PreparedStatement) conn.prepareStatement(strSQL);
    myHashMap= ResultSetToHashMapX.ResultSetToHashMap((ResultSet)pstmt1.executeQuery());
    

     }
    }catch(SQLException e1){
    System.out.println(e1.toString());
    }
    finally
    {
    
    	 if (pstmt1 != null) {
    	      try { pstmt1.close(); } catch (SQLException e) { ; }
    	      pstmt1 = null;
    	    }
    	    if (conn != null) {
    	      try { conn.close(); } catch (SQLException e) { ; }
    	      conn = null;
    	    }
    	
    }

    return myHashMap;
    }


   
  
     public String getDate1() throws SQLException
    {
    	

    		    ArrayList myArrayList=null;
    		    Connection conn=null ;
    		    PreparedStatement pstmt1 =null;
    		    String Mydate="";
    		    try{

    		    ResultSetToArrayList ResultSetToArrayListX = new ResultSetToArrayList();
    		
    		  String strSQL="select TO_CHAr(sysdate,'MONTH DD, YYYY')  from duAL";
    		    System.out.println("***strSQLstrSQL=="+strSQL);
    		System.out.println("DatabaseProcess.getResultSetTOArrayListfromSQL() = 11111111111111111111111111111111111");
    		conn = getInfoPoolConnection();
    		     if (conn != null) {
    		     pstmt1 = conn.prepareStatement(strSQL);
    		    myArrayList= ResultSetToArrayListX.ResultSetToArrayList((ResultSet)pstmt1.executeQuery());
    		ArrayList rowDAte = (ArrayList) myArrayList.get(0);
    		Mydate = rowDAte.get(0).toString();
    		     }
    		    }catch(SQLException e1){
    
    		    System.out.println(e1.toString());
    		    }finally {
    		    	 if (pstmt1 != null) {
    		    	      try { pstmt1.close(); } catch (SQLException e) { ; }
    		    	      pstmt1 = null;
    		    	    }
    		    	    if (conn != null) {
    		    	      try { conn.close(); } catch (SQLException e) { ; }
    		    	      conn = null;
    		    	    }

    		    }
    	
    		    return Mydate;
    		    }
     
      public String LoginAuditTrail(String  vUNIVERSITYEMAIL, String vTRANTYPE,
    		  String MACADDRESS, String DEVICETYPE 
    		  ,String vLOGINATTEMPTS, String   vERRORCODE 
    		  )
     {
     String sql="";
     
     
     sql =sql+" INSERT INTO TBL_LOGINAUDITTRAIL (UNIVERSITYEMAIL,TRANTYPE,MACADDRESS,DEVICETYPE,LOGINATTEMPTS,ERRORCODE,MYDATE  )  ";
     sql =sql+" VALUES ('"+vUNIVERSITYEMAIL.trim()+"' ,'"+vTRANTYPE.trim()+"' ,'"+MACADDRESS.trim()+"' ,'"+DEVICETYPE.trim()+"',"+vLOGINATTEMPTS+", "+vERRORCODE+", DATE ) ";
     return sql;
     }

     public String getYEARfromDATE(String DateVal)
     {
     String yyyy="";
     yyyy=DateVal.trim().substring(0,4);
     return  yyyy;
     }

     

}    





