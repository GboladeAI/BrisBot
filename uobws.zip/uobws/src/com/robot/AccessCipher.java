package com.robot;


//Gbolade
public class AccessCipher {


  public static void main(String [] args) {
      try{
          
        String xx=  encrypt("918416");
           System.out.println(xx);
           }catch(ArrayIndexOutOfBoundsException  aie) {/*System.out.println(aie.getMessage());*/}
  }
   private static String generateKey ()
   {
      int i = 0;
      StringBuffer sb = new StringBuffer ();
      String pi = Double.toString (round (Math.PI, 14));
      String sKey1 = pi.substring (pi.length () - 12);
      String log10 = Double.toString (round (Math.log (2), 14));
      String sKey2 = log10.substring (log10.length () - 12);

      sb = new StringBuffer ();
      sb.append (sKey1).append (sKey2);
      String sKey = sb.toString ();

      sb = new StringBuffer ();
      for (i = 0; i < 10; i++)
      {
          sb.append (sKey);
      }
      return sb.toString ();
   }

   /*
    * encrypts the given string
    */

    public static String encrypt (String aString)
   {
      String sKey = generateKey ();

      String psSourceText = aString;
      String rsDestinationText = "";

      StringBuffer sb = new StringBuffer (psSourceText);
      sb = sb.reverse ();
      psSourceText = sb.toString ();
      int nTextLength = psSourceText.length ();

      String sCurrentChar = "";
      while (nTextLength > 0)
      {
         int ascii = (int) psSourceText.charAt (0);
         psSourceText = psSourceText.substring (1);

         sCurrentChar = String.valueOf (ascii +
            Integer.parseInt (sKey.substring(nTextLength + 1, nTextLength + 2 )));

         if (sCurrentChar.length () == 1)
         {
            sb = new StringBuffer ();
            sb.append ("00").append (sCurrentChar);
            sCurrentChar = sb.toString ();
         }
         else if (sCurrentChar.length () == 2)
         {
            sb = new StringBuffer ();
            sb.append ("0").append (sCurrentChar);
            sCurrentChar = sb.toString ();
         }

         sb = new StringBuffer ();
         sb.append (rsDestinationText).append (sCurrentChar);
         rsDestinationText = sb.toString ();
         nTextLength = psSourceText.length ();

      }
      rsDestinationText = IntSkipString (rsDestinationText);
      sb = new StringBuffer (rsDestinationText);
      sb = sb.reverse ();
      rsDestinationText = sb.toString ();
      //System.out.println ("encrypted string=" + rsDestinationText);
      return rsDestinationText;
   }


   public static String decrypt (String aString)
   {
      String sKey = generateKey ();

      String psSourceText = aString;
      String rsDestinationText = "";

      StringBuffer sb = new StringBuffer (psSourceText);
      sb = sb.reverse ();
      psSourceText = sb.toString ();
      psSourceText = IntSkipString (psSourceText);

      int nTextLength = psSourceText.length () / 3;
      String sCurrentChar = "";
      while (nTextLength > 0)
      {
         sCurrentChar = psSourceText.substring (0, 3);
         psSourceText = psSourceText.substring (3);

         int ascii = Integer.parseInt (sCurrentChar);
         ascii = Integer.valueOf(sCurrentChar).intValue();
         sCurrentChar = String.valueOf ((char)(ascii
            - Integer.parseInt (sKey.substring (nTextLength + 1, nTextLength + 2))));

         sb = new StringBuffer ();
         sb.append (rsDestinationText).append (sCurrentChar);
         rsDestinationText = sb.toString ();
         nTextLength = psSourceText.length () / 3;
      }

      sb = new StringBuffer (rsDestinationText);
      sb = sb.reverse ();
      rsDestinationText = sb.toString ();
      //System.out.println ("decrypted string=" + rsDestinationText);
      return rsDestinationText;
   }

   /*
    * rounds a double to the specified no of decimal
    */
   private static double round(double val, int places) {
      long factor = (long)Math.pow(10,places);
      val = val * factor;
      long tmp = Math.round(val);
      return (double)tmp / factor;
   }

   private static String IntSkipString(String psSourceText) {
      int nBytes = 1;
      int nChunkCount;
      int nCount;
      int nMax;

      String rsDestinationText = "";
      String[] saTextChunks = new String[psSourceText.length()];
      String sTempChunk = "";
      String sTemp1 = "";

      if (psSourceText.length () % 2 == 0)
         nBytes = 2;
      else if (psSourceText.length () % 3 == 0)
         nBytes = 3;

      StringBuffer sb = new StringBuffer ();

      nCount = 2;  // start at 2 for the mod'ing
      while (psSourceText.length () != 0)
      {
         saTextChunks[ nCount ] = psSourceText.substring (0, nBytes);

         psSourceText = psSourceText.substring (nBytes);
         nCount = nCount + 1;
      }
      nMax = nCount;
      nCount = 2; // start at 2 for the mod'ing
      sTempChunk = "";
      nChunkCount = 0;

      while (nCount <= nMax)
      {
         if (nChunkCount < 2)
         {
            if (nCount % 2 == 0)
            {
               sb = new StringBuffer ();
               if (saTextChunks[ nCount ] == null)
               {
                  saTextChunks[ nCount ] = "";
               }
               sb.append (sTempChunk).append (saTextChunks[ nCount ]);
               sTempChunk = sb.toString ();
            }
            else
            {
               sb = new StringBuffer ();
               if (saTextChunks[ nCount ] == null)
               {
                  saTextChunks[ nCount ] = "";
               }
               sb.append (saTextChunks[ nCount ]).append (sTempChunk);
               sTempChunk = sb.toString ();
            }
            nChunkCount = nChunkCount + 1;
            nCount = nCount + 1;
         }
         else
         {
            sb = new StringBuffer ();
            sb.append (rsDestinationText).append (sTempChunk);
            rsDestinationText = sb.toString ();
            sTempChunk = "";
            nChunkCount = 0;
         }
      }
      sb = new StringBuffer ();
      sb.append (rsDestinationText).append (sTempChunk);
      rsDestinationText = sb.toString ();

      return rsDestinationText;
   }

}
