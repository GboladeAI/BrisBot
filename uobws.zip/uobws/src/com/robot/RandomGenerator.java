package com.robot;

import java.util.Random;
public class RandomGenerator {
	  
	  public int getRandomNumber(){
	    log("8 digit Random Numbers.");
	    
	    int START = 10000001;
	    int END = 99999999;
	    int res=00000000;
	    Random random = new Random();
	    
	  // java.util.Calendar.getInstance().getTime().
	    
	    //for (int idx = 1; idx <= 10; ++idx){
	    res=showRandomInteger(START, END, random);
	    return res;
	    //}
	    
	    //log("Done.");
	  }
	  
	  private int showRandomInteger(int aStart, int aEnd, Random aRandom){
		  int res =00000000;
	    if ( aStart > aEnd ) {
	      throw new IllegalArgumentException("Start cannot exceed End.");
	    }
	  
	    long range = (long)aEnd - (long)aStart + 1;

	    long fraction = (long)(range * aRandom.nextDouble());
	    int randomNumber =  (int)(fraction + aStart);    
	    res =randomNumber;
	    return res;
	   
	  }
	  
	  private static void log(String aMessage){
	    System.out.println(aMessage);
	  }
	} 
