package com.robot;

import java.io.FileNotFoundException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.robot.DatabaseProcess;

public class ScriptGenerator
{
	 public DatabaseProcess dd;
	    public Statement statement;

	    public ScriptGenerator()
	    {
	        dd = null;
	        statement = null;
	        try {
				dd = new DatabaseProcess();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    public ArrayList Authentication_Email(Connection conn, String universityemailaddress)
	    {
	    	ArrayList kk = new ArrayList();
	    	ResultSetToArrayList rrResultSetToArrayList= new ResultSetToArrayList();
	    	ResultSet rs = null;
	        Statement statement = null;
	        try
	        {

String sql =" select     ";
sql = sql + " A.SURNAME  ";
sql = sql + " ,A.FIRSTNAME  ";
sql = sql + " ,A.FACULTYID  ";
sql = sql + " ,C.FACULTYNAME  ";
sql = sql + " ,A.COURSEID  ";
sql = sql + " ,D.COURSENAME  ";
sql = sql + " ,A.ADMISSIONYEAR  ";
sql = sql + " ,A.DEGREEID  ";
sql = sql + " ,B.DEGREENAME  ";
sql = sql + " ,A.PASSWORD  ";
sql = sql + " ,A.LOGINATTEMPTS  ";
sql = sql + " ,A.LASTLOGINDATE  ";
sql = sql + " ,A.STATUS  ";
sql = sql + " FROM TBL_USERPROFILE A  ";
sql = sql + " , TBLDEGREES B  ";
sql = sql + " ,TBLFACULTY C  ";
sql = sql + " ,TBLCOURSES  D  ";
sql = sql + " WHERE A.DEGREEID=B.DEGREEID  ";
sql = sql + " AND A.FACULTYID=C.FACULTYID  ";
sql = sql + " AND A.COURSEID = D.COURSESID  ";
sql = sql + " AND A.FACULTYID=D.FACULTYID  ";
sql = sql + " AND A.UNIVERSITYEMAIL = '"+universityemailaddress.toLowerCase().trim()+"'       WITH UR     ";

	       	statement = conn.createStatement();
	        System.out.println("SQL::::"+sql.toString());
	            rs = (ResultSet)statement.executeQuery(sql.toString());
	            
	            kk = rrResultSetToArrayList.ResultSetToArrayList(rs);
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e)
	                {
	                    e.printStackTrace();
	                }
	                statement = null;
	            }
	        }
	        catch(SQLException e)
	        {
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e1)
	                {
	                    e1.printStackTrace();
	                }
	                statement = null;
	            
	            }
	        }
	        return kk;
	    }

	    
	    public ArrayList Societies(Connection conn, String param)
	    {
	    	ArrayList kk = new ArrayList();
	    	ResultSetToArrayList rrResultSetToArrayList= new ResultSetToArrayList();
	    	ResultSet rs = null;
	        Statement statement = null;
	        try
	        {

String sql =" select a.SOCIETIES, a.SOCIETIES_NAME from DASH019199.TBL_SOCIETIES  a where  a.STATUS='"+param+"'     WITH UR      ";

	       	statement = conn.createStatement();
	        System.out.println("SQL::::"+sql.toString());
	            rs = (ResultSet)statement.executeQuery(sql.toString());
	            
	            kk = rrResultSetToArrayList.ResultSetToArrayList(rs);
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e)
	                {
	                    e.printStackTrace();
	                }
	                statement = null;
	            }
	        }
	        catch(SQLException e)
	        {
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e1)
	                {
	                    e1.printStackTrace();
	                }
	                statement = null;
	            
	            }
	        }
	        return kk;
	    }
	    
	    public ArrayList SocietiesDetails(Connection conn, String param)
	    {
	    	ArrayList kk = new ArrayList();
	    	ResultSetToArrayList rrResultSetToArrayList= new ResultSetToArrayList();
	    	ResultSet rs = null;
	        Statement statement = null;
	        try
	        {

String sql =" select ";
sql = sql + " a.SOCIETIES,a.SOCIETIES_NAME,b.SOCIETIESDETAILSID, b.SOCIETIESDETAILSNAME   ";
sql = sql + " from DASH019199.TBL_SOCIETIES  a, DASH019199.TBL_SOCIETIESNAME b   ";
sql = sql + " where a.SOCIETIES=b.SOCIETIESID    ";
sql = sql + " and a.STATUS='"+param+"'     WITH UR     ";

	       	statement = conn.createStatement();
	        System.out.println("SQL::::"+sql.toString());
	            rs = (ResultSet)statement.executeQuery(sql.toString());
	            
	            kk = rrResultSetToArrayList.ResultSetToArrayList(rs);
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e)
	                {
	                    e.printStackTrace();
	                }
	                statement = null;
	            }
	        }
	        catch(SQLException e)
	        {
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e1)
	                {
	                    e1.printStackTrace();
	                }
	                statement = null;
	            
	            }
	        }
	        return kk;
	    }

	    public ArrayList Degrees(Connection conn, String param)
	    {
	    	ArrayList kk = new ArrayList();
	    	ResultSetToArrayList rrResultSetToArrayList= new ResultSetToArrayList();
	    	ResultSet rs = null;
	        Statement statement = null;
	        try
	        {

String sql =" select a.DEGREEID, a.DEGREENAME from DASH019199.TBLDEGREES a     WITH UR    ";

	       	statement = conn.createStatement();
	        System.out.println("SQL::::"+sql.toString());
	            rs = (ResultSet)statement.executeQuery(sql.toString());
	            
	            kk = rrResultSetToArrayList.ResultSetToArrayList(rs);
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e)
	                {
	                    e.printStackTrace();
	                }
	                statement = null;
	            }
	        }
	        catch(SQLException e)
	        {
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e1)
	                {
	                    e1.printStackTrace();
	                }
	                statement = null;
	            
	            }
	        }
	        return kk;
	    }
	  
	    public ArrayList Courses(Connection conn, String paramFACULTYID)
	    {
	    	ArrayList kk = new ArrayList();
	    	ResultSetToArrayList rrResultSetToArrayList= new ResultSetToArrayList();
	    	ResultSet rs = null;
	        Statement statement = null;
	        try
	        {

String sql ="  select a.COURSESID, a.COURSENAME from DASH019199.TBLCOURSES a where a.FACULTYID ="+paramFACULTYID+"           WITH UR     " ;

	       	statement = conn.createStatement();
	        System.out.println("SQL::::"+sql.toString());
	            rs = (ResultSet)statement.executeQuery(sql.toString());
	            
	            kk = rrResultSetToArrayList.ResultSetToArrayList(rs);
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e)
	                {
	                    e.printStackTrace();
	                }
	                statement = null;
	            }
	        }
	        catch(SQLException e)
	        {
	            if(statement != null)
	            {
	                try
	                {
	                	statement.close();
	                }
	                catch(SQLException e1)
	                {
	                    e1.printStackTrace();
	                }
	                statement = null;
	            
	            }
	        }
	        return kk;
	    }
	  
	     
	    	    
  
}


