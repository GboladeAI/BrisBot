package com.robot;
/*
 * ResultSetToHashMap.java
 *
 * Created on March 26, 2007, 11:17 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */


/**
 *
 * @author ShadaA
 */
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class ResultSetToHashMap
{
public ArrayList columnHeaders;
public HashMap   tableData;

public  HashMap ResultSetToHashMap( ResultSet rset)
throws SQLException {
	try{

ResultSetMetaData rsResultSet = (ResultSetMetaData) rset.getMetaData();
int count = rsResultSet.getColumnCount();
String res="";
 tableData = new  HashMap  ();

rset.next();
for (int i= 1; i<= count ; i++)
{
        if (rset.getObject(i)==null)
               res="";
        else
              res =rset.getObject(i).toString();

tableData.put(rsResultSet.getColumnName(i).toString().toUpperCase(),res);
}


}catch(Exception gg)
{
	tableData.put("ERROR","002");
	}
return tableData;
}

}



