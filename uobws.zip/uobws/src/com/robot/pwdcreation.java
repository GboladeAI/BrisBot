package com.robot;
//cf push  uobws  -b java_buildpack  -p axis2.war -m 512M
//cf bind-service uobws  dashDB-mn
//cf logs uobws --recent
//?cf restage uobws
//AAA
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;
public class pwdcreation {

	/** Creates a new instance of pwdcreation 
	 * 
	 * 
	 * 
	 * 
	RENT_ID TENANT_ID APARTNUMBER BEGINDATE ENDDATE REGISTERDATE DESCRIPTION
 RECEITPTNO CAUTIONFEE RENT  from rent a,
 
 
 
	 
RENT_ID TENANT_ID APARTNUMBER BEGINDATE ENDDATE REGISTERDATE DESCRIPTION

 SELECT a.APARTNUMBER,a.RECEITPTNO , a.RENT ,a.BEGINDATE,b.ENDDATE,b.TENANT_MOBILENUMBER, b.FIRSTNAME  
 from rent a, tenant b, apartment c
 where  a.tenant_id=c.tenant_id
 and a.APARTNUMBER=c.APARTNUMBER
 and b.APARTNUMBER=c.APARTNUMBER
 

HOMEOWNER_MOBILENUMBER1, HOMEOWNER_ID, STREET, STREET1, LGA, STATE, COUNTRY, 
APARTNUMBER, REGISTERDATE, APARTMENTTYPE, APARTMENTDESCRIPTION, apartmentcode, 
STATUS   from  APARTMENT


select TENANT_MOBILENUMBER, FIRSTNAME, LASTNAME  from  tenant

	 * 
	 * 
	 * 
	 * 
	 * 
	 * */
	public String pwdcreationgen(String Mypassword) {
      
      
		String password = Mypassword.trim() ;  //get password



//Digest passord
byte[] newPasswordDigestBytes = null;

try {
	MessageDigest msgDigestEngine = MessageDigest.getInstance("MD5");
	msgDigestEngine.update(password.getBytes());
	newPasswordDigestBytes = msgDigestEngine.digest();
	
	
} catch (NoSuchAlgorithmException ex) {
	ex.printStackTrace();


}


//Encode digest to base64 to make it text
Base64 codecBase64 = new Base64();
byte[] newPasswordDigestBase64 = codecBase64.encode(newPasswordDigestBytes);


StringBuffer newPasswordDigest = new StringBuffer();
for (int i=0; i<newPasswordDigestBase64.length;i++) {
	 newPasswordDigest.append((char)newPasswordDigestBase64[i]);
}
return newPasswordDigest.toString().trim();

	}
  
	
 
}
