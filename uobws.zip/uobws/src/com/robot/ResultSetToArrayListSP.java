package com.robot;



/*
*Author 		:Shada A Taiwo
*Directorate	        :Information Technology
*Department		:Business System Development
*Unit			:Research & Development
*Date Created	        :16th of September, 2004
 *
*
*
*/

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



public class ResultSetToArrayListSP
{
	public ArrayList < String > columnHeaders;
	public ArrayList < ArrayList > tableData;
	public ArrayList < String > rowData;
	public int RowCount=0;


public  ArrayList ResultSetToArrayListSP( ResultSet rset, int intNumCols)
throws SQLException {

	tableData = new  ArrayList ();
while (rset.next())
{//begin while
rowData = new ArrayList();

for (int i=1; i<=intNumCols; i++)
{
 if (rset.getObject(i)==null)
 {
     rowData.add(" ");
 }
 else
 {
rowData.add(rset.getObject(i).toString());
}
}
tableData.add(rowData);
rowData=null; /// set rowData ArrayList to null after the addition to tableData ArrayList
RowCount=RowCount+1;
}
return tableData;
}
public int getRowCount()
{
return tableData.size();
}

}



