package com.robot;


/**
 * Write a description of class PropertiesFileReader here.
 *
 * @author ShadaA
 * @version (a version number or a date)
 */


import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Properties;


public class PropertiesFileReader {
    private static Properties props;    
    private static String applicationPropFile;

    private PropertiesFileReader() { } 
    
    private static void loadPropertyFile () throws IOException {         
         props = new Properties();
         URL configFileURL = PropertiesFileReader.class.getResource(getApplicationPropFile());
         String filePath = URLDecoder.decode(configFileURL.getPath(), "UTF-8");          
         FileInputStream configFile = new FileInputStream(filePath);
         props.load(configFile);
         configFile.close();
    }
    public static Properties getProperties(String propFile)  throws Exception {
    	setApplicationPropFile(propFile);
        if(props==null) loadPropertyFile();
        return props;
    }
	/**
	 * @param apllicationPropFile The apllicationPropFile to set.
	 */
	private static void setApplicationPropFile(String appPropFile){
		applicationPropFile = appPropFile;
	}
	/**
	 * @return Returns the applicationPropFile.
	 */
	private static String getApplicationPropFile() {
		return applicationPropFile;
	}
}
