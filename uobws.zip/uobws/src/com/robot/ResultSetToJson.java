package com.robot;

/**
 *
 * @author akingboladeshada
 */
//public class ResultSetToJson 
/*
*Author 		:Shada A Taiwo
*Directorate	        :Information Technology
*Department		:Business System Development
*Unit			:Research & Development
*Date Created	        :16th of September, 2004
 *
*
*
*/

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import com.google.gson.*;



public class ResultSetToJson
{
public ArrayList < String > columnHeaders;
public ArrayList < ArrayList > tableData;
public ArrayList < String > rowData;
public int RowCount=0;
public JsonArray recordsArray ;


public  JsonArray ResultSetToJson( final ResultSet rset)
throws SQLException {

ResultSetMetaData rsResultSet = (ResultSetMetaData) rset.getMetaData();
int count = rsResultSet.getColumnCount();
columnHeaders = new ArrayList ();
 recordsArray = new JsonArray();
 JsonArray tableArray = new JsonArray();
tableData = new  ArrayList();
JsonObject currentRecord = null;
for (int i= 1; i<= count ; i++)
{
columnHeaders.add(rsResultSet.getColumnName(i));
}
int k=1;
//rset.beforeFirst();
while (rset.next())
{//begin while
	recordsArray = new JsonArray();
	rowData = new ArrayList();
	 currentRecord = new JsonObject();
	for (int i=1; i<=count; i++)
	{
		 if (rset.getObject(i)==null)
		 {
		     rowData.add(" ");
		 }
		 else
		 {
			rowData.add(rset.getObject(i).toString());
			currentRecord.add(columnHeaders.get(i-1).toString().toUpperCase(),new JsonPrimitive(rset.getObject(i).toString()));
			//recordsArray.add(currentRecord);
		 }
	}
	
	k++;
	System.out.println("sequence:::"+k);
	tableArray.add(currentRecord);
	tableData.add(rowData);
	rowData=null; /// set rowData ArrayList to null after the addition to tableData ArrayList
	RowCount=RowCount+1;
}// end while
return tableArray;
}





public   ArrayList ColumnNames(ResultSet rset) throws SQLException {
ResultSetMetaData rsResultSet = (ResultSetMetaData) rset.getMetaData();
int count = rsResultSet.getColumnCount();
columnHeaders = new ArrayList < String >(count);
tableData = new  ArrayList < ArrayList >();

for (int i= 1; i<= count ; i++)
{
columnHeaders.add(rsResultSet.getColumnName(i));
}
return columnHeaders;
}

public int getColumnCount()
{
return columnHeaders.size();
}

public int getRowCount()
{
return tableData.size();
}

}




    
