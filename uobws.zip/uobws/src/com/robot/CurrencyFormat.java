package com.robot;


import java.text.DecimalFormat;
import java.text.NumberFormat;
public class CurrencyFormat {
  private  String Amt_Val;
  private  Double fAmt_Val;
  private Float floatAmt;
  String tmpAmt_Val;
  public CurrencyFormat (String AmountValue){
	if (AmountValue.trim().length()==0)
	{
		 AmountValue="00"+AmountValue; 
	}
	  AmountValue=AmountValue; 
      AmountValue=AmountValue.replaceAll(",","");
        Amt_Val = AmountValue;
        try{
            fAmt_Val = Double.valueOf(AmountValue);

        }catch(NumberFormatException e){
            Amt_Val = "0";
        }

  }
  public String getFormat() {
   NumberFormat formatter;
   //formatter = new DecimalFormat("#,###,###,###,##0.00");
   formatter = new DecimalFormat("#,###,###,###,##0.00");
   String myString = formatter.format(fAmt_Val);

   String sValue = myString;

   return sValue.trim();
  }
  
  public String getFormatWithoutDecimal() {
   NumberFormat formatter;
   formatter = new DecimalFormat("#,###,###,###,##0");
   String myString = formatter.format(fAmt_Val);
   String sValue = myString;
   return sValue.trim();
  }
}