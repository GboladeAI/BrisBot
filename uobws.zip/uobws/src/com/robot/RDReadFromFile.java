package com.robot;


/*
*Author 		:Shada A Taiwo
*Directorate	        :Information Technology
*Department		:Business System Development
*Unit			:Research & Development
*Date Created	        :16th of September, 2004
*
*
*/


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
public class RDReadFromFile {
  private BufferedReader br = null;
  private FileReader fr = null;
  private ArrayList al = null;

  public RDReadFromFile(String file) throws IOException, IllegalArgumentException {
    String rLine=null;
    try {
      al = new ArrayList(50);
      fr = new FileReader(file);
      br = new BufferedReader(fr);
      rLine = br.readLine();
      while( rLine != null ) {
        rLine = rLine.trim().replace('\t', ' ');
        al.add(rLine);
        rLine = br.readLine();
      }
      fr.close();
    
    }catch (IOException ex) {
      System.out.println("Error:" + ex.toString());
      throw ex;
    }
  }

  public String getPropFromFile(String prop)
                        throws IOException{
    String rLine=null;
    Iterator iter = al.iterator();

    if( al==null)
      throw new IOException("Null reference exists for file variables");

    while( iter.hasNext() ) {
      rLine = (String) iter.next();
      if(rLine.regionMatches(true,0,prop,0,prop.length())) {
        break;
      }else {
        rLine = null;
      }
    }

    if (rLine == null) return null;
    if (rLine.equals("")) return null;

    int idx = rLine.indexOf("=");
    if (idx == -1) return null;
    rLine = rLine.substring(idx+1);
    if (rLine == null) return null;
    rLine = rLine.trim();
    if (rLine.equals("")) return null;

    return rLine;
  }

   public int getIntPropFromFile(String prop)
                              throws Exception, NumberFormatException {
    int val = 0;
    try {
      String str = getPropFromFile(prop);
      val = Integer.parseInt(str);
    }catch(Exception ex) {
      throw ex;
    }

    return val;
  }

  public boolean setPropToFile(String propkey, String value)
                        throws IOException{
    System.out.println("Inside setPropToFile" + propkey + value );
    String rLine=null;
    String rfirst=null;
    String rlast = null;
    FileWriter iWrite = new FileWriter("Rates.config");
    int pos= 0;
    Iterator iter = al.iterator();
    Iterator iterw = al.iterator();
    if( al==null){
      System.out.println("a1 Null");
      throw new IOException("Null reference exists for file variables");
    }
    while( iter.hasNext() ) {
      rLine = (String) iter.next();
      if(rLine.regionMatches(true,0,propkey,0,propkey.length())) {
        pos = al.indexOf(rLine);
        System.out.println(rLine);
        break;
      }else {
        rLine = null;
        System.out.println(rLine + "is Null");
      }
    }

    if (rLine == null) return false;
    if (rLine.equals("")) return false;

    int idx = rLine.indexOf("=");
    if (idx == -1) return false;
    rfirst = rLine.substring(0, idx+1);
    rlast = rLine.substring(idx+1);
    rlast = value;
    rLine = rfirst + rlast;
    if (rLine == null) return false;
    rLine = rLine.trim();
    if (rLine.equals("")) return false;
    al.set(pos,rLine);
    while( iterw.hasNext() ) {
      rLine = (String) iterw.next();
      iWrite.write(rLine);
      iWrite.write("\n");
      }
     iWrite.flush();
     iWrite.close();
    return true;
  }

  public void close() throws IOException{
    al=null;
  }
  public static String getPropFromFile(String prop, String file)
                        throws IOException{
    BufferedReader br;
    FileReader fr;
    String rLine;

    try{
      fr = new FileReader(file);
      br = new BufferedReader(fr);
      rLine = br.readLine();
      while( rLine != null ) {
        rLine = rLine.trim().replace('\t', ' ');
        if(rLine.regionMatches(true,0,prop,0,prop.length())) {
          break;
        }else {
          rLine = null;
        }
        rLine = br.readLine();
      }
      fr.close();
      br.close();
    }catch (FileNotFoundException ex) {
      System.out.println("Error: Properties file " + file + " Not Found");
      throw ex;
    }catch (IOException ex) {
      System.out.println("Error:" + ex.toString());
      throw ex;
    }finally  {
      fr = null;
      br = null;
    }

    if (rLine == null) return null;
    if (rLine.equals("")) return null;

    int idx = rLine.indexOf("=");
    if (idx == -1) return null;
    rLine = rLine.substring(idx+1);
    if (rLine == null) return null;
    rLine = rLine.trim();
    if (rLine.equals("")) return null;

    return rLine;
  }


  public int getIntPropFromFile(String prop, String file)
                              throws IOException, NumberFormatException {
    int val = 0;
    try {
      String str = getPropFromFile(prop, file);
      val = Integer.parseInt(str);
    }catch(IOException ex) {
      throw ex;
    }catch(NumberFormatException ex) {
      throw ex;
    }

    return val;
  }

  public boolean setPropToFile(String propkey, String value, String FileName)
                        throws IOException{

    String rLine=null;
    String rfirst=null;
    String rlast = null;
    FileWriter iWrite = new FileWriter(FileName);
    int pos= 0;
    Iterator iter = al.iterator();
    Iterator iterw = al.iterator();

     System.out.println("Inside setPropToFile" + propkey + value );

    if( al==null){
    //  System.out.println("a1 Null");
      throw new IOException("Null reference exists for file variables");
    }
    while( iter.hasNext() ) {
      rLine = (String) iter.next();
      if(rLine.regionMatches(true,0,propkey,0,propkey.length())) {
        pos = al.indexOf(rLine);
        System.out.println(rLine);
        break;
      }else {
        rLine = null;
     //   System.out.println(rLine + "is Null");
      }
    }

    if (rLine == null) return false;
    if (rLine.equals("")) return false;

    int idx = rLine.indexOf("=");
    if (idx == -1) return false;
    rfirst = rLine.substring(0, idx+1);
    rlast = rLine.substring(idx+1);
    rlast = value;
    rLine = rfirst + rlast;
    if (rLine == null) return false;
    rLine = rLine.trim();
    if (rLine.equals("")) return false;
    al.set(pos,rLine);
    while( iterw.hasNext() ) {
      rLine = (String) iterw.next();
      iWrite.write(rLine);
      iWrite.write("\n");
      }
     iWrite.flush();
     iWrite.close();
System.out.println("Outside setPropToFile" + propkey + value );
    return true;
  }


}