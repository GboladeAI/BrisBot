
package com.robot;
//---alter table DASH019199.TBL_PEOPLESOCIETITES add constraint PK_SOCIETIES primary key (UNIVERSITYEMAILADDRESS, SOCIETIESDETAILSID)
// cf push  uobws  -b java_buildpack  -p axis2.war

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.Courses;
import com.bean.Degrees;
import com.bean.LoginDetails;
import com.bean.MyInfo;
import com.bean.Societies;
import com.bean.SocietiesDetails;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.robot.DatabaseProcess;
import com.robot.ScriptGenerator;
import com.robot.pwdcreation;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageRequest;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageResponse;
import com.ibm.watson.developer_cloud.conversation.v1.ConversationService;
import com.ibm.watson.developer_cloud.http.ServiceCall;
import com.ibm.watson.developer_cloud.service.exception.BadRequestException;
import com.ibm.watson.developer_cloud.service.exception.InternalServerErrorException;
import com.ibm.watson.developer_cloud.service.exception.UnauthorizedException;


public class UoBRobotservices2 {
	
	
	public String getAuthentication( String universityemailaddress, String password, String MACADDRESS,String DeviceType, String Latitude,String Longitude )
	{
		 
		 String ret="";
		 LoginDetails vLoginDetails = new LoginDetails()		 ;
		 ArrayList vArrList=null;
		 System.out.println("*****************************************");
		 System.out.println(universityemailaddress);
		 System.out.println(MACADDRESS);
		 System.out.println(DeviceType);
		 System.out.println(Latitude);
		 System.out.println(Longitude);
		System.out.println("*****************************************");
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		
		pwdcreation pwdgen = new pwdcreation();
		ScriptGenerator ss =new ScriptGenerator();
		ArrayList arrval = new ArrayList();
		
		//String mypass = pwdgen.pwdcreationgen(password);
		String errorcode="09";
			vArrList = ss.Authentication_Email(conn, universityemailaddress);
          ArrayList RowAl = new ArrayList();
			if (vArrList.size()>=1)
			{
				
				RowAl= (ArrayList)vArrList.get(0);
				vLoginDetails.setSURNAME(RowAl.get(0).toString()) ;
			    vLoginDetails.setFIRSTNAME(RowAl.get(1).toString()) ;
			    vLoginDetails.setFACULTYID(RowAl.get(2).toString()) ;
			    vLoginDetails.setFACULTYNAME(RowAl.get(3).toString()) ;
			    vLoginDetails.setCOURSEID(RowAl.get(4).toString()) ;
			    vLoginDetails.setCOURSENAME(RowAl.get(5).toString()) ;
			    vLoginDetails.setADMISSIONYEAR(RowAl.get(6).toString()) ;
			    vLoginDetails.setDEGREEID(RowAl.get(7).toString()) ;
			    vLoginDetails.setDEGREENAME(RowAl.get(8).toString()) ;
			    vLoginDetails.setPASSWORD(RowAl.get(9).toString()) ;
			    vLoginDetails.setLOGINATTEMPTS(RowAl.get(10).toString()) ;
			    vLoginDetails.setLASTLOGINDATE(RowAl.get(11).toString()) ;
			    vLoginDetails.setSTATUS(RowAl.get(12).toString()) ;
			    vLoginDetails.setRESPONSECODE("00") ;
			    errorcode="00";

				RowAl=null;
					
		}else
		{
			
			vLoginDetails.setSURNAME("") ;
		    vLoginDetails.setFIRSTNAME("") ;
		    vLoginDetails.setFACULTYID("") ;
		    vLoginDetails.setFACULTYNAME("") ;
		    vLoginDetails.setCOURSEID("") ;
		    vLoginDetails.setCOURSENAME("") ;
		    vLoginDetails.setADMISSIONYEAR("") ;
		    vLoginDetails.setDEGREEID("") ;
		    vLoginDetails.setDEGREENAME("") ;
		    vLoginDetails.setPASSWORD("") ;
		    vLoginDetails.setLOGINATTEMPTS("") ;
		    vLoginDetails.setLASTLOGINDATE("") ;
		    vLoginDetails.setSTATUS("") ;
		    vLoginDetails.setRESPONSECODE("01") ;
		    errorcode="01";

			RowAl=null;
		}
			arrval=null;
			
			
			 String ssql= "  INSERT INTO  DASH019199.TBL_LOGINAUDITTRAIL ";
			 ssql=ssql +  "  ( ";
			 ssql=ssql +  "        MYDATE   ";
			 ssql=ssql +  "         ,UNIVERSITYEMAIL  ";
			 ssql=ssql +  " 	,TRANTYPE ";
			 ssql=ssql +  "  	,MACADDRESS  ";
			 ssql=ssql +  "  	,DEVICETYPE ";
			 ssql=ssql +  "          ,LATITUDE  ";
			 ssql=ssql +  "          ,LONGITUDE  ";
			 ssql=ssql +  "  	,LOGINATTEMPTS  ";
			 ssql=ssql +  "  	,ERRORCODE  ";
			 ssql=ssql +  " 	 ) ";
			 ssql=ssql +  " 		 VALUES   ";
			 ssql=ssql +  " 		 (   ";
			 ssql=ssql +  " CURRENT DATE   ";
			 ssql=ssql +  " ,'"+universityemailaddress+"'";
			 ssql=ssql +  " ,'00' ";
			 ssql=ssql +  " ,'"+MACADDRESS+"'   ";
			 ssql=ssql +  " ,'"+DeviceType+"'  ";
			 ssql=ssql +  " ,'"+Latitude+"'   ";
			 ssql=ssql +  " ,'"+Longitude+"'   ";
			 ssql=ssql +  " , 0   ";
			 ssql=ssql +  " ,'"+errorcode+"'   ";
			 ssql=ssql +  " )  ";
			 System.out.println("Log authentication:::"+ssql);
			 String response="";
				try {
					response = dd.executeInsertDB2(ssql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					 System.out.println("Exceptio:::"+e.getMessage());
					 System.out.println("getLocalizedMessage:::"+e.getLocalizedMessage());
				}
			if (conn != null) {
	       	      try { conn.close(); } catch (SQLException e) { ; }
	       	      conn = null;
	       	    }
			 Gson gson = new Gson();
			 ret =gson.toJson(vLoginDetails).toString();
System.out.println("response::::::::::"+ret);
		return ret;
	}
	public String getSocieties( String paramStatus )
	{
		 
		 String ret="";
		
		 MyInfo vMyInfo = new MyInfo();
		 ArrayList vArrList=null;
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		Societies var[] = null;
        
		ScriptGenerator ss =new ScriptGenerator();
		
		ArrayList arrval = new ArrayList();
		
		
			vArrList = ss.Societies(conn, paramStatus);
          ArrayList RowAl = new ArrayList();
          int arrsize=vArrList.size();
          var = new Societies[arrsize];
  		
			if (vArrList.size()>=1)
			{
				for (int i=0; i< arrsize; i++)
				{
				RowAl= (ArrayList)vArrList.get(i);
				 Societies vSocieties = new Societies()		 ;
				vSocieties.setSOCIETIES(RowAl.get(0).toString()) ;
				vSocieties.setSOCIETIES_NAME(RowAl.get(1).toString());
			    
				var[i]=vSocieties;
				
				RowAl=null;
				
				}
					
		}else
		{
			var = new Societies[1];
			 Societies vSocieties = new Societies()		 ;
			vSocieties.setSOCIETIES("") ;
			vSocieties.setSOCIETIES_NAME("");
		    var[0]=vSocieties;
			RowAl=null;
		}
			arrval=null;
			
			vMyInfo.setSocieties(var);
			
			 Gson gson = new Gson();
			 ret =gson.toJson(vMyInfo).toString();
System.out.println("response::::::::::"+ret);
		
		return ret;

	}

	public String getSocietiesDetails( String paramStatus )
	{
		 
		 String ret="";
		
		 SocietiesDetails var[]=null; 
		 MyInfo vMyInfo = new MyInfo();
		 ArrayList vArrList=null;
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		
		
		ScriptGenerator ss =new ScriptGenerator();
		
		ArrayList arrval = new ArrayList();
		
		
			vArrList = ss.SocietiesDetails(conn, paramStatus);
			  var = new SocietiesDetails[vArrList.size()];
          ArrayList RowAl = new ArrayList();
			if (vArrList.size()>=1)
			{
				for(int i =0 ; i <vArrList.size(); i++)
				{
					 SocietiesDetails vSocietiesDetails = new SocietiesDetails()		 ;
				RowAl= (ArrayList)vArrList.get(i);
				vSocietiesDetails.setSOCIETIES(RowAl.get(0).toString()) ;
				vSocietiesDetails.setSOCIETIES_NAME(RowAl.get(1).toString());
				vSocietiesDetails.setSOCIETIESDETAILSID(RowAl.get(2).toString());
				vSocietiesDetails.setSOCIETIESDETAILSNAME(RowAl.get(3).toString());
			    
				var[i]=vSocietiesDetails;
				
				RowAl=null;
				}
					
		}else
		{
			var = new SocietiesDetails[1];
			 SocietiesDetails vSocietiesDetails = new SocietiesDetails()		 ;
			vSocietiesDetails.setSOCIETIES("");
			vSocietiesDetails.setSOCIETIES_NAME("");
			vSocietiesDetails.setSOCIETIESDETAILSID("");
			vSocietiesDetails.setSOCIETIESDETAILSNAME("");
			var[0]=vSocietiesDetails;
		
		    
			RowAl=null;
		}
			arrval=null;
			
       	    if (conn != null) {
       	      try { conn.close(); } catch (SQLException e) { ; }
       	      conn = null;
       	    }
			vMyInfo.setSocietiesDetails(var);
			 Gson gson = new Gson();
			 ret =gson.toJson(vMyInfo);

		
		return ret;
		
		
		

	}

	public String getDegrees( String param )
	{
		 
		 String ret="";
		 Degrees var[]=null; 
		 MyInfo vMyInfo = new MyInfo();
		 ArrayList vArrList=null;
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		
		
		ScriptGenerator ss =new ScriptGenerator();
		
		ArrayList arrval = new ArrayList();
		
		
			vArrList = ss.Degrees(conn, param);
			
			int arrsize=vArrList.size();
	       ArrayList RowAl = new ArrayList();
			if (vArrList.size()>=1)
			{
				  var = new Degrees[arrsize];
				  for(int i=0; i<arrsize; i++)
				  { 
					  Degrees vDegrees = new Degrees()		 ;
						
					  RowAl= (ArrayList)vArrList.get(i);
				vDegrees.setDEGREEID(RowAl.get(0).toString()) ;
				vDegrees.setDEGREENAME(RowAl.get(1).toString());
			    var[i]=vDegrees;
				RowAl=null;
				  }
		}else
		{
			 Degrees vDegrees = new Degrees()		 ;
				
			var = new Degrees[1];
			vDegrees.setDEGREEID("") ;
			vDegrees.setDEGREENAME("");
			var[0]=vDegrees;
			RowAl=null;
		}
			arrval=null;
		
			
		
		vMyInfo.setDegrees(var);
		
		 Gson gson = new Gson();
		 ret =gson.toJson(vMyInfo).toString();

		
		 System.out.println("response::::::::::"+ret);
			
			return ret;

	}

	
	public String getCourses( String paramFACULTYID )
	{
		 
		 String ret="";
		 ArrayList vArrList=null;
		 
		 Courses var[]=null; 
		 MyInfo vMyInfo = new MyInfo();
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection conn = dd.getDBConnection();
		
		
		ScriptGenerator ss =new ScriptGenerator();
	
		ArrayList arrval = new ArrayList();
		
		
			vArrList = ss.Courses(conn, paramFACULTYID);
          ArrayList RowAl = new ArrayList();
          int arrsize= vArrList.size();
          
          if (vArrList.size()>=1)
			{
                var = new Courses[arrsize]	 ; 
                for(int i=0; i<arrsize ; i++)
                {
           		 Courses vCourses = new Courses()		 ;

                	RowAl= (ArrayList)vArrList.get(i);
				vCourses.setCOURSESID(RowAl.get(0).toString());
				vCourses.setCOURSENAME(RowAl.get(1).toString());
				RowAl=null;
				var[i]=vCourses;
                }
					
		}else
		{

			var = new Courses[1]	 ; 
			 Courses vCourses = new Courses()		 ;

			vCourses.setCOURSESID("");
			vCourses.setCOURSENAME("");
			var[0]=vCourses;
			RowAl=null;
		}
			arrval=null;
		
			
       	    if (conn != null) {
       	      try { conn.close(); } catch (SQLException e) { ; }
       	      conn = null;
       	    }
			
		vMyInfo.setCourses(var);
		
		 Gson gson = new Gson();
		 ret =gson.toJson(vMyInfo).toString();

	
		 System.out.println("response::::::::::"+ret);
			
			return ret;

	}

	
	public String CreateSocieties(String universityemailaddress,String societiesdetailsid,String status,
			String type)
	{
		String response="";
		String sql = "   ";
		
		if (type.equalsIgnoreCase("INSERT"))
		{
		 sql = " INSERT INTO DASH019199.TBL_PEOPLESOCIETITES ";
		sql=sql + " VALUES('"+universityemailaddress+"', "+societiesdetailsid+ ", '"+status+"' )";
		}
		if (type.equalsIgnoreCase("UPDATE"))
		{
		 sql = "UPDATE DASH019199.TBL_PEOPLESOCIETITES ";
		sql=sql + " SET STATUS = '"+status+"' ";
		sql=sql + " WHERE UNIVERSITYEMAILADDRESS = '"+universityemailaddress+"' ";
		sql=sql + " AND societiesdetailsid = '"+societiesdetailsid+"' ";
		}
		 System.out.println("sql :::"+sql);
		 DatabaseProcess dd =null;
		try {
			 dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			response = dd.executeInsertDB2(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			 System.out.println("Exceptio:::"+e.getMessage());
			 System.out.println("getLocalizedMessage:::"+e.getLocalizedMessage());
		}
	
		return response;
	}

	public String CreatePOSTPERSUBJECT(String universityemailaddress,String SubjectCode,String question,String status
			)
	{
		String response="";
		String sql = "   ";
		
		
		//CreatePOSTPERSUBJECT?universityemailaddress=as16247@my.bristol.ac.uk&SubjectCode=COMSM2127&question=What is Neuroscience&status=A
		
		 sql = "INSERT INTO DASH019199.TBL_POSTPERSUBJECT(MYDATE,UNIVERSITYEMAILADDRESS,SUBJECTCODE,QUESTION  ,STATUS)";
		sql=sql + " VALUES(CURRENT DATE,'"+universityemailaddress+"','"+SubjectCode+"', '"+question.replaceAll("'","")+ "', '"+status+"' )";
		
		 System.out.println("sql :::"+sql);
		 DatabaseProcess dd =null;
		try {
			 dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			response = dd.executeInsertDB2(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			 System.out.println("Exceptio:::"+e.getMessage());
			 System.out.println("getLocalizedMessage:::"+e.getLocalizedMessage());
		}
	
		return response;
	}
	
	
	public String CreatePOSTRESPONSEPERSUBJECT(String universityemailaddress,String SubjectCode,String question,String status,String QUESTIONID
			)
	{
		String response="";
		String sql = "   ";
		 sql = "INSERT INTO DASH019199.TBL_POSTRESPONSEPERSUBJECT(MYDATE,UNIVERSITYEMAILADDRESS,SUBJECTCODE,ANSWER  ,STATUS, QUESTIONID)";
		sql=sql + " VALUES(CURRENT DATE,'"+universityemailaddress+"','"+SubjectCode+"', '"+question.replaceAll("'","")+ "', '"+status+"',"+QUESTIONID+" )";
		
		
//http://uobws.mybluemix.net/services/UoBRobotservices2/CreatePOSTRESPONSEPERSUBJECT?universityemailaddress=as16247@my.bristol.ac.uk&SubjectCode=COMSM2127&question=Nuoeroscince is the study of  Brain and creating such pattern in computing platform&status=A&QUESTIONID=1
		
		 System.out.println("sql :::"+sql);
		 DatabaseProcess dd =null;
		try {
			 dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			response = dd.executeInsertDB2(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			 System.out.println("Exceptio:::"+e.getMessage());
			 System.out.println("getLocalizedMessage:::"+e.getLocalizedMessage());
		}
	
		return response;
	}



	public String getRegisteredSocietiesDetails( String universityemailaddress )
	{ 
		 JsonArray ret=null;
		
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		String sql= "  SELECT    ";
sql = sql + "   A.UNIVERSITYEMAILADDRESS   ";
sql = sql + "   ,B.SOCIETIES   ";
sql = sql + "   ,B.SOCIETIES_NAME   ";
sql = sql + "   ,C.SOCIETIESDETAILSID   ";
sql = sql + "   ,C.SOCIETIESDETAILSNAME   ";
sql = sql + "   ,A.STATUS   ";

sql = sql + "   from DASH019199.TBL_PEOPLESOCIETITES A, DASH019199.TBL_SOCIETIES B   ";
sql = sql + "   ,DASH019199.TBL_SOCIETIESNAME C   ";
sql = sql + "   		WHERE 1=1   ";
sql = sql + "   		and A.SOCIETIESDETAILSID = C.SOCIETIESDETAILSID   ";
sql = sql + "   		AND B.SOCIETIES = C.SOCIETIESID   ";
sql = sql + "   		AND A.UNIVERSITYEMAILADDRESS = '"+universityemailaddress+"'" ;

sql = sql + "   		ORDER by A.STATUS  ASC   WITH UR  ";
try {
	ret = dd.getResultSetTOJsonfromSQLForDB2(sql);
} catch (SQLException e) {
	System.out.println("SQL::::::"+ sql);
	System.out.println("ERror::::::"+ e.getMessage());
System.out.println("getLocalizedMessage::::::"+ e.getLocalizedMessage());
System.out.println("getSQLState::::::"+ e.getSQLState());

}
String response = ret.toString();	

System.out.println("response::::::"+ response);

		return response;
		
		
		

	}


	public String getPOSTTHREADSLIST( String QUESTIONID )
	{ 
		 JsonArray ret=null;
		
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql=" ";
	//	sql=sql+"   select QUESTIONID, SUBJECTCODE, QUESTION, MYDATE, STATUS, UNIVERSITYEMAILADDRESS from TBL_POSTPERSUBJECT   ";
	//	sql=sql+"  WHERE QUESTIONID = "+QUESTIONID+"  AND STATUS='A'   ";
	//	sql=sql+"  UNION   ";
		sql=sql+"  select QUESTIONID, SUBJECTCODE, ANSWER, MYDATE, STATUS, UNIVERSITYEMAILADDRESS from TBL_POSTRESPONSEPERSUBJECT  ";
		sql=sql+"  WHERE QUESTIONID ="+QUESTIONID+"  AND STATUS='A'   ";
		sql=sql+"  ORDER BY 4 ASC      WITH UR                ";
		
		
		
try {
	ret = dd.getResultSetTOJsonfromSQLForDB2(sql);
} catch (SQLException e) {
	System.out.println("SQL::::::"+ sql);
	System.out.println("ERror::::::"+ e.getMessage());
System.out.println("getLocalizedMessage::::::"+ e.getLocalizedMessage());
System.out.println("getSQLState::::::"+ e.getSQLState());

}
String response = ret.toString();	

System.out.println("response::::::"+ response);

		return response;
		
		
		

	}

	
	
	public String getQUESTIONSLIST( String FacultyID )
	{ 
		 JsonArray ret=null;
		
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		String sql="     select   ";
sql=sql+"   a.QUESTIONID  ";
sql=sql+"   ,a.SUBJECTCODE  ";
sql=sql+"   ,a.QUESTION  ";
sql=sql+"   ,a.MYDATE  ";
sql=sql+"   ,a.UNIVERSITYEMAILADDRESS  ";
sql=sql+"   ,b.FACULTYID  ";
sql=sql+"   ,b.SUBJECTTITLE  ";
sql=sql+"   ,b.UNIT  ";
sql=sql+"   		 from DASH019199.TBL_POSTPERSUBJECT a,DASH019199.TBL_SUBJECTS b   ";

sql=sql+"   where a.SUBJECTCODE=b.SUBJECTCODE   ";
sql=sql+"   and a.STATUS='A'  ";
sql=sql+"   and b.FACULTYID="+FacultyID + "   " ;

sql=sql+"  ORDER BY 2 ASC, 4 ASC       WITH UR                    ";

		
		
try {
	ret = dd.getResultSetTOJsonfromSQLForDB2(sql);
} catch (SQLException e) {
	System.out.println("SQL::::::"+ sql);
	System.out.println("ERror::::::"+ e.getMessage());
System.out.println("getLocalizedMessage::::::"+ e.getLocalizedMessage());
System.out.println("getSQLState::::::"+ e.getSQLState());

}
String response = ret.toString();	

System.out.println("response::::::"+ response);

		return response;
		
		
		

	}

	
	
	
	
	public String getSubjectInFaculty( String paramFacultyID )
	{ 
		 JsonArray ret=null;
		
		 
		DatabaseProcess dd = null;
		try {
			dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

String sql= " select a.SUBJECTID, a.FACULTYID, a.SUBJECTCODE, a.UNIT, a.SUBJECTTITLE   ";
sql = sql + " from DASH019199.TBL_SUBJECTS a    ";
sql = sql + " where a.FACULTYID = "+paramFacultyID+ "     WITH UR     ";


try {
	ret = dd.getResultSetTOJsonfromSQLForDB2(sql);
} catch (SQLException e) {
	System.out.println("SQL::::::"+ sql);
	System.out.println("ERror::::::"+ e.getMessage());
System.out.println("getLocalizedMessage::::::"+ e.getLocalizedMessage());
System.out.println("getSQLState::::::"+ e.getSQLState());

}
String response = ret.toString();	

System.out.println("response::::::"+ response);

		return response;
		
		
		

	}

	public String getChatResponseFromRobot( String universityemailaddress,String request )
	{ 
		 String Response="response from ROBOT";
		 try {
			    
			    
			   
			 String version=    com.ibm.watson.developer_cloud.conversation.v1.ConversationService.VERSION_DATE_2016_07_11;
			 ConversationService service = new ConversationService(version,"d58eb40d-a6c8-492a-8717-e24189afc742", "JC0Yf7DrZLqC");
			 System.out.println(":::::::::111111111::::::::::");
			 
			 java.util.Properties pp = new java.util.Properties();
			 
			 service.setEndPoint("https://gateway.watsonplatform.net/conversation/api");
			 
			 service.setUsernameAndPassword("d58eb40d-a6c8-492a-8717-e24189afc742", "JC0Yf7DrZLqC");
			 MessageRequest newMessage = new MessageRequest.Builder().inputText(request).build();
			 String workspaceId = "d37b4acc-8c2d-44ff-8e50-4706630d21f8";
			 
			 MessageResponse response =new MessageResponse();
			 List<String> resp = new ArrayList<String>();
			 resp = service.message("d37b4acc-8c2d-44ff-8e50-4706630d21f8", newMessage).execute().getText();
			
		 int k=resp.size();

		 System.out.println(resp);

		 if (k>0)
		 {
			 System.out.println(resp.get(0).toString());
			 Response=resp.get(0).toString();
		 }else
		 {
			 Response="UoB has not created  the knowledgebase for this request...";
		 }
		 
		 /////LOG THIS...

		String sql = "INSERT INTO DASH019199.TBL_LOGCHAT(MYDATE,UNIVERSITYEMAILADDRESS,REQUEST,RESPONSE)";
		sql=sql + " VALUES(CURRENT DATE,'"+universityemailaddress+"','"+request+"', '"+Response.replaceAll("'","")+"' )";
		
		 System.out.println("sql :::"+sql);
		 DatabaseProcess dd =null;
		try {
			 dd = new DatabaseProcess();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String res="";
		try {
			res = dd.executeInsertDB2(sql);
			if (res.equalsIgnoreCase("Y"))
				System.out.println("Successsfully logged the  response for the chatt::::");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 System.out.println("Exceptio:::"+e.getMessage());
			 System.out.println("getLocalizedMessage:::"+e.getLocalizedMessage());
			
		}
		 
		 
		 
		 
		 ////////////


		   // Your code goes here
		 } catch (IllegalArgumentException e) {
			 System.out.println("IllegalArgumentExceptionExceptio:::"+e.getMessage());
			 System.out.println("IllegalArgumentExceptiongetLocalizedMessage:::"+e.getLocalizedMessage());
		   // Missing or invalid parameter
		 } catch (BadRequestException e) {
			 System.out.println("BadRequestExceptionExceptio:::"+e.getMessage());
			 System.out.println("BadRequestExceptiongetLocalizedMessage:::"+e.getLocalizedMessage());
		   // Missing or invalid parameter
		 } catch (UnauthorizedException e) {
			 System.out.println("UnauthorizedExceptionExceptio:::"+e.getMessage());
			 System.out.println("UnauthorizedExceptiongetLocalizedMessage:::"+e.getLocalizedMessage());
		   // Access is denied due to invalid credentials
		 } catch (InternalServerErrorException e) {
			 System.out.println("InternalServerErrorExceptionExceptio:::"+e.getMessage());
			 System.out.println("InternalServerErrorExceptiongetLocalizedMessage:::"+e.getLocalizedMessage());
		   // Internal Server Error
		 
		 
		} catch (NullPointerException e) {
			e.printStackTrace();
		 System.out.println("NullPointerException:::"+e.getMessage());
		 System.out.println("NullPointerException:::"+e.getLocalizedMessage());
		// e.getSuppressed().
	   // Internal Server Error
	 }
		 
		 

		         
		  
		     

		

		return Response;
		
		
		

	}


}

